# ServiceAgent-RL：电商客服工具调用的 SFT 与 ART 强化学习

保留智能客服场景，基于官方 tau-bench retail 的任务、数据库、业务政策和状态评分，对同一个 Qwen2.5-3B-Instruct 做 Base → LoRA SFT → GRPO 对照。2026-10-14完成实现修复与重训：在相同40个测试任务、两个评测种子的配对复测中，SFT成功率为 **16.25%（13/80）**，修复后的SFT＋GRPO为 **22.50%（18/80）**，观察提升 **6.25个百分点**；平均工具调用10.25→9.5875。按任务聚类的95% bootstrap差值区间为[-5.00,+17.50]个百分点，仍不足以证明稳定提升。完整结果见[修复实验报告](experiments/retail-grpo-repair/attention_report.md)。

原始实验的Base/SFT/GRPO成功率7.5%、20%、10%保留在[历史实验报告](experiments/retail-3b/report.md)，不与本轮复测基线混用。本次未重新训练SFT；GRPO各组均从同一原SFT检查点开始。

本次实验只使用一张 RTX 4090 D 24GB（GPU 0）。教师、用户模拟器和自然语言裁判使用外部 API，本地卡用于学生模型。[固定实验协议](experiments/retail-3b/protocol.md)记录数据划分、训练参数与采样预算。

2026-10-13至14日完成六组GRPO诊断与修复，覆盖结果奖励、SFT参考KL、有界过程惩罚、训练/采样数值一致性、业务进度奖励及打包注意力掩码。确认并修复Unsloth覆盖ART分支掩码的问题，原五组作为诊断对照。F采样96条有效轨迹、完成21次更新，按开发集选择第7次更新后的step8进行完整测试，而非使用最后权重。方案见[改进协议](experiments/retail-grpo-repair/protocol.md)，诊断见[原因分析](experiments/retail-grpo-repair/diagnosis.md)，过程见[实验日志](experiments/retail-grpo-repair/journal.md)。两个种子是评测重复，本轮只有一个训练种子。

## 数据来源

- [官方 tau-bench 仓库](https://github.com/sierra-research/tau2-bench)，固定 commit `5bfa7e37b36656b37dc6d022156be6563c1007f3`，上游包版本 1.0.1，仓库现称 τ³-bench。
- 已下载 **114 个 retail 任务、订单/商品/用户数据库、业务政策、用户模拟器提示、配套源码和许可证**。按 Git blob 校验下载，落盘生成 SHA-256 清单。
- 官方 train/test = 74/40。本项目只从官方训练部分留出开发集，得到 **train 59 / dev 15 / test 40**。按完全相同的用户场景分组，不宣称按模板族隔离。
- 这是官方公开的模拟业务基准，不是电商平台真实生产聊天记录，也不是现成 SFT 对话集。SFT 对话需要教师与用户模拟器交互生成，自动过滤后抽样审核。
- 采用官方 reward_basis：部分任务只检查数据库，部分还调用自然语言裁判。官方成功不等于全部政策合规，报告中的全面违规率保留为空。

## 架构与数据流

```mermaid
flowchart TD
    D[官方任务、政策、数据库] --> S[训练59 / 开发15 / 测试40]
    S -->|仅训练任务| T[教师模型 ↔ 用户模拟器 ↔ 官方工具环境]
    T --> V[官方评分与轨迹记录]
    V --> F[成功轨迹过滤、去重、抽样审核]
    F --> J[SFT数据：messages + tools]
    J --> SFT[ART LoRA SFT：3B学生模型]
    SFT --> R[同一任务采样多条学生轨迹]
    R --> E[执行工具、改变模拟订单状态]
    E --> W[官方结果 + 训练业务进度 - 有界过程惩罚]
    W --> G[ART组内相对优势 + SFT参考KL约束]
    G --> R
    G --> C[检查点 / LoRA权重]
    C --> Q[开发集选型 / 独立测试集评测]
    S -->|留出任务| Q
    Q --> O[完整trace、指标、版本记录]
```

学生只收到政策、工具说明、用户消息和工具反馈；标准动作与评分条件留在环境/评测侧。训练后的用户交互使用模型与工具服务；奖励计算和反向传播属于训练/离线评测。当前未接入生产订单系统。

## 1. 安装和检查（uv）

从项目根目录执行。全新检出必须先下载上游文件，因为 tau2 是本地路径依赖。

```bash
PYTHONPATH=src python -m mini_customer_agent.retail.data
uv sync --extra retail --extra dev --locked
uv run --extra retail --extra dev --locked retail-agent inspect
uv run --extra retail --extra dev --locked python -m unittest discover -s tests -v
```

环境代理不可用而可直接联网时，下载命令追加 `--direct`。`retail-prepare --verify` 复验下载清单。GPU训练依赖单独安装：

```bash
uv sync --project runtimes/art --locked
uv run --project runtimes/art --locked retail-agent prepare-inference
```

ART固定 **0.5.16**，训练环境锁定 PyTorch **2.9.1 / CUDA 12.8**、Transformers **4.57.3**、Unsloth **2025.12.9**、vLLM **0.15.1**。推理与训练依赖统一安装在 `runtimes/art/.venv`，与根目录API环境隔离。`prepare-inference`检查已安装版本，不启动模型。若配置本地模型路径，则直接读取已有权重；仅使用远端模型ID时才下载权重。

本机配置和阶段入口见 [本地部署说明](docs/local_setup.md)。`scripts/retail.sh`封装了单卡运行命令。

旧版 `train` extra / TRL 环境仅服务历史示例，当前主流程不使用旧版四卡命令。

## 2. 配置模型

复制 `configs/retail.example.json` 为 `configs/retail.json`，复制 `.env.example` 为 `.env`，填写真实模型、地址和密钥。

| 配置 | 用途 |
|---|---|
| `agent` | 已启动的 OpenAI-compatible 学生服务，供普通 `evaluate` 使用 |
| `teacher` | 外部 API 教师，采集训练任务示范 |
| `user` | 外部 API 用户模拟器，补充信息、确认业务操作 |
| `judge` | 外部 API 裁判，处理官方 NL_ASSERTION |
| `art` | ART管理的本地学生模型、LoRA训练与推理 |

教师模型填接口原始模型名；用户/裁判经 LiteLLM 调用，兼容 OpenAI 的服务用 `openai/模型名`。比较 Base/SFT/GRPO 时固定用户模型、裁判、任务划分和评测参数。`.env` 自动加载，已有环境变量优先；密钥不写进 JSON。

## 3. 采集与 SFT 数据构建

### 使用 Qwen 3.7 Flash

新增配置 `configs/retail.qwen37.example.json`，采用用户提供的接口地址
`https://maas.qianwenaiapi.com/compatible-mode/v1`。填写与该服务匹配的密钥；也可以用环境变量改为你的供应商地址。

在项目根目录 `.env` 中填写：

```dotenv
DASHSCOPE_BASE_URL=https://maas.qianwenaiapi.com/compatible-mode/v1
DASHSCOPE_API_KEY=你的服务密钥
```

Qwen专用配置的三个云端角色默认共用这套环境变量。已有 `TEACHER_*`、`USER_*`、`JUDGE_*` 非空时优先使用各自配置；旧配置中的其他模型名或密钥不会被自动改写。使用时显式指定Qwen配置，或将其复制为自己的 `configs/retail.json`。

```bash
# 单次流式请求，测试教师连接，不开始采集或训练
uv run --extra retail --locked retail-agent --config configs/retail.qwen37.example.json probe

# 对应提供的思考+流式示例：单独显示接口返回的reasoning_content和正文
uv run --extra retail --locked retail-agent --config configs/retail.qwen37.example.json \
  probe --thinking --show-reasoning --max-tokens 8192

# 接口通过后，采集3个正式客服任务
uv run --extra retail --locked retail-agent --config configs/retail.qwen37.example.json \
  collect --limit 3 --trials 1
```

教师默认 `stream: true`、`extra_body: {"enable_thinking": false}`；用户模拟器和裁判非流式调用并显式关闭思考。需要教师思考时，在自己的JSON里将 `enable_thinking` 改为 `true` 并提高 `max_tokens`，如8192；这个预算含模型思考所消耗的输出。`probe --thinking`只影响该次检查，不修改采集配置。

适配器会拼接流式文本、工具名称、JSON参数及末尾token用量，流中断会报错；正式采集沿用完整工具执行闭环。教师思考文本与回复分开，正常轨迹的SFT `messages`不包含思考文本。若设置 `preserve_thinking: true`，后续教师请求会回传历史思考内容；该行为参考[供应商参数文档](https://help.aliyun.com/zh/model-studio/deep-thinking)，具体网关兼容性仍需真实调用确认。ART学生训练继续使用原非流式客户端，保留原始Choice与logprobs。

`probe`通过只说明文本接口可用，仍需要`collect`验证工具调用、用户模拟器及裁判。正式实验固定模型快照和思考设置；不要混合不同教师设置后把数据当作同一批。

```bash
uv run --extra retail --locked retail-agent --config configs/retail.json collect --limit 3 --trials 1
uv run --extra retail --locked retail-agent --config configs/retail.json build-sft \
  --traces traces/retail/实际采集目录/traces.jsonl --output data/sft/train.jsonl
```

先检查 3 个任务，再去掉 `--limit`，用 `--trials 3` 扩大采样。59 是独立训练任务数；同场景多次采样可生成多条轨迹，不能算作更多独立场景。

筛选器只接受训练划分内的教师轨迹，拒绝测试数据、版本不符、失败、工具报错、截断和消息不配对样本，记录来源哈希和自动筛选标记。仍需抽查确认、订单归属和退换货规则；不伪装人工审核。

## 4. 单卡 Base → SFT → GRPO

先选择可用卡。下面的 0 是示例，应替换为你实际可用的卡编号。默认 4-bit 加载、LoRA rank 16、SFT batch 1、8192 上下文、同任务 2 条串行 rollout。SFT前检查全部样本长度，超长时停止，防止ART静默丢弃样本；仍需实测显存，不应截掉业务政策。

```bash
export CUDA_VISIBLE_DEVICES=0

# 新 art.name 尚无检查点时，评测 Base
uv run --project runtimes/art --locked retail-agent --config configs/retail.json \
  train --stage evaluate --split dev --limit 15

uv run --project runtimes/art --locked retail-agent --config configs/retail.json \
  train --stage sft --dataset data/sft/train.jsonl --epochs 1

# 先保存 SFT 评测，再做 RL
uv run --project runtimes/art --locked retail-agent --config configs/retail.json \
  train --stage evaluate --split dev --limit 15

uv run --project runtimes/art --locked retail-agent --config configs/retail.json \
  train --stage grpo --steps 5 --limit 3

uv run --project runtimes/art --locked retail-agent --config configs/retail.json \
  train --stage evaluate --split dev --limit 15
```

`--steps` 是采样组数，组内奖励相同则记录并跳过梯度更新，真实更新数见 `updates.jsonl`。扩大 RL 用 `--limit 59`；频繁全失败/全成功时，应先解决奖励无差异问题，再延长训练。

`sft-grpo` 可串起两个阶段并在中间记录小规模 SFT 开发集评测。正式实验建议分阶段：同一 `art.name` 续训 SFT→RL，新对照用新名称。SFT不覆盖已有训练检查点；网络/裁判故障中止，不能充当奖励0。

实验配置冻结后，在各阶段用 `--stage evaluate --split test --limit 40` 保存相同协议的测试结果。当前命令评测最新检查点，需在进入下一阶段前保存当前阶段结果；测试结果不用于反复调参。

## 目录职责

| 目录 | 作用 |
|---|---|
| **`src/mini_customer_agent/retail/`** | 新主流程：下载、划分、官方环境适配、SFT数据、ART训练和评测 |
| **`configs/`** | 模型和训练配置，不保存密钥 |
| **`data/tau2/`** | 数据版本/哈希清单、固定 train/dev/test ID |
| **`third_party/tau2-bench/`** | 固定版本官方源码和原始零售数据，自动下载 |
| **`data/sft/`** | 筛选后的教师示范及数据清单，采集后生成 |
| **`runtimes/art/`** | 独立GPU训练依赖、锁文件和虚拟环境 |
| **`traces/retail/`** | 每次运行的对话、工具结果、评分、指标与版本 |
| **`.art/`** | ART检查点、LoRA、训练状态和日志，训练时生成 |
| `.cache/local-models/` | 引用原始权重、修正工具参数格式的本地模型配置副本 |
| `tests/` | 回归测试、数据边界及官方工具环境离线联调 |
| `docs/` | 架构解释、运行说明、旧版文档归档 |
| `src/mini_customer_agent/` 其他模块、`training/`、`data/tasks/` | 原四工具 Mini Harness 和 TRL 示例，保留作学习参考 |

优先阅读 `retail/cli.py`（入口）、`retail/rollout.py`（多轮数据流）、`retail/dataset.py`（数据边界）、`retail/training.py`（训练循环）。详细解释见 [架构说明](docs/retail_architecture.md)。

## 输出与实验边界

`run.json` 保存配置/包版本/代码版本；`traces.jsonl` 保存工具参数、反馈、评分和终止原因；`metrics.json` 汇总成功率、工具错误及调用数。ART运行另存 `arguments.json`，RL另存 `updates.jsonl`。尚未按供应商计价汇总教师、用户和裁判的真实费用。

Base、SFT、GRPO的提升必须来自实际对照评测，不能把数据下载完成或脚本测试通过写成模型能力提升。旧版说明保留在 [legacy_harness.md](docs/legacy_harness.md)。
