"""Report the attention follow-up independently of the original five-arm choice."""
import csv
import json
import random
import statistics
from pathlib import Path
import report_retail_grpo_repair as base_report

ROOT,OUT=base_report.ROOT,base_report.OUT


def main():
    base_report.main()
    runs=json.loads((OUT/'runs.json').read_text())
    lines=['# 注意力掩码修复：后续实验','',
           'F从同一SFT起点训练，与E仅增加打包注意力掩码修复；原五组的选择记录保留。',
           '官方任务成功率与数值测试分开报告。']
    selection_path=OUT/'selection-attention.json'
    if selection_path.exists():
        decision=json.loads(selection_path.read_text());candidate=decision['selected']
        sft=decision['sft_combined_score'][0];success=candidate['combined_score'][0]
        lines+=['',f"开发选型：F step {candidate['step']}（第{candidate['round']}组）；"
                f"seed42={candidate['seed42_score'][0]}/15，seed43={candidate['seed43_score'][0]}/15。",
                f'两种子合计：SFT {sft}/30={sft/30:.1%}；F {success}/30={success/30:.1%}。',
                '开发集参与选型，两个种子复用同一批15个任务，不能作为独立测试性能。',
                '通过开发门槛，测试见下方完整记录。' if success>sft else
                '未通过开发门槛，未运行F测试，不宣称任务成功率提升。']
    else:
        lines+=['','尚未完成开发选型。']
    pairs=[]
    lines+=['','| 模型 | 测试种子 | 成功/覆盖 | 成功率 | 工具错误任务比例 | 平均调用 |',
            '|---|---:|---:|---:|---:|---:|']
    for seed in (42,43):
        rows_by_model={}
        for model in ('sft','attention'):
            name=f'{model}-test{seed}'
            if name not in runs:continue
            rows={r['task_id']:r for r in base_report.records(ROOT/runs[name]/'traces.jsonl')
                  if r['split']=='test' and not r.get('error')}
            rows_by_model[model]=rows
            if rows:
                metrics=base_report.summarize(list(rows.values()))
                lines.append(f"| {model} | {seed} | {metrics['successes']}/{metrics['tasks']} | "
                    f"{metrics['success_rate']:.1%} | {metrics['tool_error_episode_rate']:.1%} | {metrics['avg_tool_calls']:.2f} |")
        before,after=rows_by_model.get('sft',{}),rows_by_model.get('attention',{})
        if len(before)==40 and set(before)==set(after):
            pairs.extend({'seed':seed,'task_id':task,'sft':int(before[task]['success']),
                          'attention':int(after[task]['success'])} for task in sorted(before))
    if pairs:
        with (OUT/'paired_test-attention.csv').open('w') as handle:
            writer=csv.DictWriter(handle,fieldnames=list(pairs[0]));writer.writeheader();writer.writerows(pairs)
    if len(pairs)==80:
        clusters={}
        for row in pairs:clusters.setdefault(row['task_id'],[]).append(row['attention']-row['sft'])
        deltas=[statistics.mean(v) for v in clusters.values()]
        rng=random.Random(42)
        boot=sorted(statistics.mean(rng.choices(deltas,k=40)) for _ in range(10000))
        result={'episodes':80,'sft_success':sum(r['sft'] for r in pairs),
                'attention_success':sum(r['attention'] for r in pairs),
                'gains':sum(r['attention']>r['sft'] for r in pairs),
                'losses':sum(r['attention']<r['sft'] for r in pairs),
                'delta':statistics.mean(deltas),'cluster_bootstrap_95ci':[boot[250],boot[9749]],
                'note':'40 task clusters, two evaluation seeds; one training seed; known benchmark follow-up'}
        (OUT/'paired_summary-attention.json').write_text(json.dumps(result,indent=2)+'\n')
        lines+=['','## 完整配对结果','','```json',json.dumps(result,indent=2),'```']
    replay_path=ROOT/'.art/service-agent-retail/models/qwen25-3b-repair-attention/attention_audit.json'
    if replay_path.exists():
        replay=json.loads(replay_path.read_text())
        lines+=['','## 相同3B权重与输入的只读掩码对照','',
                '| 序列 | 打包位置偏离比例 | 原MAE | 保留掩码MAE | 原超出裁剪区间比例 | 保留掩码比例 |',
                '|---|---:|---:|---:|---:|---:|']
        for sequence in replay['sequences']:
            old=sequence['variants']['overwritten'];new=sequence['variants']['preserved']
            lines.append(f"| {sequence['index']} | {old['packed_position_reset_fraction']:.1%} | "
                f"{old['old_policy_logprob_mae']:.5f} | {new['old_policy_logprob_mae']:.5f} | "
                f"{old['old_policy_ratio_outside_clip']:.1%} | {new['old_policy_ratio_outside_clip']:.1%} |")
        lines+=['',replay['note'],'这是概率一致性证据，不是任务成功率。']
    lines+=['','完整训练计数、逐轮开发评测和异常尝试见report.md；配置、协议和过程见protocol.md及journal.md。']
    (OUT/'attention_report.md').write_text('\n'.join(lines)+'\n')


if __name__=='__main__':main()
