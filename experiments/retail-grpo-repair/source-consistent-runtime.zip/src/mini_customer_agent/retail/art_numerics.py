"""Pass ART's existing packed token positions through to the model's RoPE.

The pinned ART shared Unsloth path prepares input_pos but does not forward it.
This optional adapter retains the upstream objective and attention mask.
"""
from contextvars import ContextVar


def install_plain_weight_dispatch(implementation):
    """Avoid probing an optional quantizer for ordinary, unquantized weights.

    PEFT 0.18 checks TorchAO's version before inspecting the tensor type. The
    locked runtime's TorchAO is older; ordinary BF16 LoRA does not use it.
    Tensor subclasses (including actual TorchAO weights) retain native checks.
    """
    import torch
    if getattr(implementation, '_retail_plain_weight_dispatch', False):
        return
    original = implementation.dispatch_torchao

    def dispatch(target, *args, **kwargs):
        base = target.get_base_layer() if hasattr(target, 'get_base_layer') else target
        if type(getattr(base, 'weight', None)) in (torch.Tensor, torch.nn.Parameter):
            return None
        return original(target, *args, **kwargs)

    implementation.dispatch_torchao = dispatch
    implementation._retail_plain_weight_dispatch = True


def install_packed_positions(implementation):
    if getattr(implementation, '_retail_positions_installed', False):
        return
    positions = ContextVar('retail_packed_positions', default=None)
    original_factory = implementation.get_compute_loss_fn
    original_calculate = implementation.calculate_logprobs

    def get_compute_loss_fn(trainer):
        original = original_factory(trainer)
        def compute_loss(model, inputs, *args, **kwargs):
            token = positions.set(inputs['input_pos'])
            try:
                return original(model, inputs, *args, **kwargs)
            finally:
                positions.reset(token)
        return compute_loss

    def calculate_logprobs(*args, **kwargs):
        if not getattr(implementation, '_retail_positions_enabled', True):
            return original_calculate(*args, **kwargs)
        current = positions.get()
        if current is None:
            raise RuntimeError('Packed positions missing from trainer inputs')
        if len(args) >= 5:
            args = list(args)
            args[4] = {**args[4], 'position_ids': current.to(args[2].device)}
        else:
            kwargs['forward_kwargs'] = {**kwargs.get('forward_kwargs', {}),
                                       'position_ids': current.to(kwargs['input_ids'].device)}
        return original_calculate(*args, **kwargs)

    implementation.get_compute_loss_fn = get_compute_loss_fn
    implementation.calculate_logprobs = calculate_logprobs
    implementation._retail_positions_installed = True


def replay_probability_audit(implementation, trainer, request, config, experimental_config):
    """Read-only replay of the control's first packed batch, before this run's update."""
    import hashlib
    import json
    from pathlib import Path
    import torch
    from art.preprocessing.pack import packed_tensors_from_dir
    from .logprobs import probability_diagnostics

    descriptor_path = Path(request['descriptor'])
    descriptor = json.loads(descriptor_path.read_text())
    packed = packed_tensors_from_dir(**descriptor)
    batch = {key: value[:1] for key, value in packed.items()}
    result = {'source_descriptor': str(descriptor_path),
              'descriptor_sha256': hashlib.sha256(descriptor_path.read_bytes()).hexdigest(),
              'before_first_reported_update': True, 'variants': {}}
    original_setting = getattr(implementation, '_retail_positions_enabled', True)
    try:
        for enabled in [False, True]:
            implementation._retail_positions_enabled = enabled
            inputs = {**batch, 'config': config, '_config': experimental_config,
                      'return_new_logprobs': True}
            # Native return-new-logprobs bypasses the loss, backward and update.
            shifted = implementation.get_compute_loss_fn(trainer)(trainer.model, inputs)
            unshifted = torch.nn.functional.pad(shifted[:, 1:], (0, 1))
            metrics = probability_diagnostics({key: value.to(shifted.device)
                                               for key, value in batch.items() if isinstance(value, torch.Tensor)},
                                              unshifted, experimental_config.get('epsilon', .2))
            result['variants']['bf16_fp32_positions' if enabled else 'bf16_fp32'] = metrics
            del shifted, unshifted
    finally:
        implementation._retail_positions_enabled = original_setting
    return result
