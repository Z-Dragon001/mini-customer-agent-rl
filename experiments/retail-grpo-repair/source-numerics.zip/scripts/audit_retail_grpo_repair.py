"""Audit completed real runs, reward integrity, held-out isolation and selection."""
import hashlib
import json
import math
from pathlib import Path

from mini_customer_agent.retail.rewards import reward_breakdown, group_is_informative

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT/'experiments/retail-grpo-repair'


def read(path):
    return json.loads(path.read_text())


def records(path):
    return [json.loads(line) for line in path.read_text().splitlines()]


def main():
    runs=read(OUT/'runs.json')
    splits=read(ROOT/'data/tau2/splits.json')
    checks=[]
    def check(name, condition):
        checks.append({'check':name,'passed':bool(condition)})
    for arm in ('outcome','kl','shaped','consistent'):
        folder=ROOT/runs[arm]
        spec=read(folder/'run.json')['config']['art']
        rows=records(folder/'traces.jsonl')
        updates=records(folder/'updates.jsonl')
        selected={(r['group_id'],r['rollout_index']):r for r in rows
                  if r['split']=='train' and not r.get('error')}
        check(arm+':24 contiguous groups',[r['iteration'] for r in updates]==list(range(24)))
        check(arm+':96 selected trajectories',set(selected)=={(g,i) for g in range(24) for i in range(4)})
        check(arm+':train-only tasks',all(r['task_id'] in splits['train'] for r in selected.values()))
        for group in updates:
            trajectories=[selected[group['iteration'],i] for i in range(4)]
            expected=[reward_breakdown(r,spec['reward']) for r in trajectories]
            check(f'{arm}:group{group["iteration"]}:reward',
                  all(a['training_reward']==b for a,b in zip(trajectories,expected))
                  and group['rewards']==[b['total'] for b in expected])
            check(f'{arm}:group{group["iteration"]}:update',
                  group['updated']==group_is_informative(group['rewards'],[r['success'] for r in trajectories],spec['reward']))
            check(f'{arm}:group{group["iteration"]}:seed',
                  all(r['seed']==1042+group['iteration'] for r in trajectories))
        expected_step=1+sum(u['updated'] for u in updates)
        check(arm+':final checkpoint step',updates[-1]['policy_step']==expected_step)
        model=ROOT/spec['path']/spec['project']/'models'/spec['name']
        for step in range(2,expected_step+1):
            check(f'{arm}:optimizer{step}',(model/'checkpoints'/f'{step:04d}'/'retail_optimizer.pt').exists())
        for round_id in (8,16,24):
            dev={r['task_id']:r for r in rows if r['split']=='dev' and
                 r.get('evaluation_round')==round_id and not r.get('error')}
            check(f'{arm}:dev{round_id}',set(dev)==set(splits['dev']))
        metrics=records(folder/'grpo_batch_metrics.jsonl')
        check(arm+':finite updates',all(math.isfinite(v) for row in metrics for v in row['metrics'].values()
                                      if isinstance(v,(float,int))))
        if arm!='outcome':
            check(arm+':KL measured',bool(metrics) and all('kl_div' in m['metrics'] for m in metrics))
    frozen=read(OUT/'selection.json')
    for seed in (42,43):
        for stage in ('sft','selected'):
            folder=ROOT/runs[f'{stage}-test{seed}']
            rows=records(folder/'traces.jsonl')
            valid={r['task_id']:r for r in rows if not r.get('error')}
            check(f'{stage}:test{seed}:coverage',set(valid)==set(splits['test']))
            check(f'{stage}:test{seed}:split',all(r['split']=='test' and r['seed']==seed for r in valid.values()))
            if stage=='selected':
                check(f'selected:test{seed}:frozen checkpoint',all(r['policy_step']==frozen['selected']['step'] for r in valid.values()))
    for path,digest in read(OUT/'source_checkpoint.json').items():
        check('original SFT unchanged:'+Path(path).name,hashlib.sha256((ROOT/path).read_bytes()).hexdigest()==digest)
    result={'passed':all(c['passed'] for c in checks),'checks':checks,
            'limits':['Does not assert a positive effect or full policy compliance',
                      'Remote user/judge aliases and generation are not fully deterministic']}
    (OUT/'audit.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'passed':result['passed'],'checks':len(checks),
                      'failed':[c for c in checks if not c['passed']]},indent=2))
    if not result['passed']:
        raise SystemExit(1)


if __name__=='__main__':
    main()
