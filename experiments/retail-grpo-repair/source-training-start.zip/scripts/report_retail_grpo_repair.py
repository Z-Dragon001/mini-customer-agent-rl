"""Derive comparison tables from saved real trajectories, including partial runs."""
from collections import Counter
import csv
import json
from pathlib import Path
import random
import statistics

from mini_customer_agent.retail.rewards import process_signals

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT/'experiments/retail-grpo-repair'


def records(path):
    if not path.exists():
        return []
    content = path.read_text()
    lines = content.splitlines()
    if content and not content.endswith('\n'):
        lines = lines[:-1]
    return [json.loads(line) for line in lines]


def summarize(rows):
    n = len(rows)
    signals = [process_signals(row) for row in rows]
    return dict(tasks=n, successes=sum(r['success'] for r in rows),
                success_rate=sum(r['success'] for r in rows)/n,
                tool_error_episode_rate=sum(r['tool_errors']>0 for r in rows)/n,
                avg_tool_calls=statistics.mean(r['tool_calls'] for r in rows),
                repeated_calls=sum(s['repeated_calls'] for s in signals),
                budget_exhausted=sum(s['budget_exhausted'] for s in signals))


def main():
    runs = json.loads((OUT/'runs.json').read_text())
    tables, training, evaluations = [], {}, {}
    for name, path in runs.items():
        folder = ROOT/path
        rows = records(folder/'traces.jsonl')
        grouped = {}
        for row in rows:
            if row.get('error') or row['split']=='train':
                continue
            group = (row['split'], row.get('evaluation_round', -1), row['seed'], row.get('policy_step'))
            grouped.setdefault(group, {})[row['task_id']] = row
        for (split, round_id, seed, step), selected in sorted(grouped.items()):
            valid = list(selected.values())
            tables.append(dict(run=name, split=split, round=round_id, seed=seed,
                               step=step, **summarize(valid)))
            evaluations[name,split,round_id] = selected
        updates = records(folder/'updates.jsonl')
        if updates:
            selected = {(r['group_id'],r['rollout_index']):r for r in rows
                        if r['split']=='train' and not r.get('error')}
            counts = Counter('updated' if r['updated'] else 'skipped' for r in updates)
            metrics = records(folder/'grpo_batch_metrics.jsonl')
            training[name] = dict(groups=len(updates), selected_trajectories=len(selected),
                                  policy_updates=counts['updated'], skipped_groups=counts['skipped'],
                                  optimizer_batches=len(metrics),
                                  train_successes=sum(r['success'] for r in selected.values()))
    if tables:
        with (OUT/'results.csv').open('w') as handle:
            writer=csv.DictWriter(handle,fieldnames=list(tables[0]))
            writer.writeheader()
            writer.writerows(tables)
    (OUT/'training_summary.json').write_text(json.dumps(training,indent=2)+'\n')
    lines=['# GRPO 改进实验结果', '',
           '每行覆盖必须达到 dev 15 或 test 40 才能作为该次完整评测。过程奖励不替代官方成功率。', '',
           '| 实验 | 划分/种子/轮次 | 成功 | 成功率 | 工具错误任务比例 | 平均调用 | 重复调用 | 预算耗尽 |',
           '|---|---|---:|---:|---:|---:|---:|---:|']
    for row in tables:
        lines.append(f"| {row['run']} | {row['split']}/{row['seed']}/{row['round']} | "
                     f"{row['successes']}/{row['tasks']} | {row['success_rate']:.1%} | "
                     f"{row['tool_error_episode_rate']:.1%} | {row['avg_tool_calls']:.2f} | "
                     f"{row['repeated_calls']} | {row['budget_exhausted']} |")
    lines+=['', '## 实际训练', '', '```json', json.dumps(training,ensure_ascii=False,indent=2), '```']
    pairs=[]
    for seed in [42,43]:
        base=evaluations.get((f'sft-test{seed}','test',-1),{})
        candidate=evaluations.get((f'selected-test{seed}','test',-1),{})
        if len(base)==40 and set(base)==set(candidate):
            for task in sorted(base):
                pairs.append(dict(seed=seed,task_id=task,sft=int(base[task]['success']),
                                  grpo=int(candidate[task]['success'])))
    if pairs:
        with (OUT/'paired_test.csv').open('w') as handle:
            writer=csv.DictWriter(handle,fieldnames=list(pairs[0]))
            writer.writeheader();writer.writerows(pairs)
    if len(pairs)==80:
        gains=sum(p['grpo']>p['sft'] for p in pairs)
        losses=sum(p['grpo']<p['sft'] for p in pairs)
        clusters={}
        for p in pairs:
            clusters.setdefault(p['task_id'],[]).append(p['grpo']-p['sft'])
        deltas=[statistics.mean(v) for v in clusters.values()]
        rng=random.Random(42)
        boot=sorted(statistics.mean(rng.choices(deltas,k=len(deltas))) for _ in range(10000))
        result=dict(episodes=80,sft_success=sum(p['sft'] for p in pairs),
                    grpo_success=sum(p['grpo'] for p in pairs),gains=gains,losses=losses,
                    delta=statistics.mean(deltas),cluster_bootstrap_95ci=[boot[250],boot[9749]],
                    note='40 task clusters × 2 evaluation seeds; not two independent training seeds')
        (OUT/'paired_summary.json').write_text(json.dumps(result,indent=2)+'\n')
        lines+=['','## 冻结选择后的配对测试','', '```json', json.dumps(result,indent=2), '```']
    lines+=['', '旧测试任务已在前次实验分析中出现；本次使用开发集选型，报告为已知基准上的后续改进。',
            '尚未实现全面政策违规率验证。两次评测种子不等于两个独立训练种子。',
            '计划和过程分别见 protocol.md、journal.md；最终候选选择见 selection.json（选型后生成）。']
    (OUT/'report.md').write_text('\n'.join(lines)+'\n')
    print(json.dumps({'evaluations':len(tables),'training':training},indent=2))


if __name__=='__main__':
    main()
