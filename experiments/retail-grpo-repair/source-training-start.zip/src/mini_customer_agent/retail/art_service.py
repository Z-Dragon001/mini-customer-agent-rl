"""Narrow compatibility fixes for the locked ART 0.5.16 / Unsloth runtime."""
from __future__ import annotations

import json
import os
from pathlib import Path

# Unsloth must patch transformers before the training service imports it.
import unsloth  # noqa: F401
from art.local import LocalBackend
from art.unsloth.service import UnslothService


class RetailUnslothService(UnslothService):
    def __init__(self, *args, persist_optimizer=False, **kwargs):
        super().__init__(*args, **kwargs)
        self.persist_optimizer = persist_optimizer
        self._optimizer_restored = False

    async def _train_shared(self, disk_packed_tensors, config, _config, verbose=False):
        import importlib
        from .logprobs import checkpointed_logprobs
        implementation = importlib.import_module("art.unsloth.train")
        # Upstream chunks the projection, but autograd retains every chunk's
        # vocabulary-sized intermediates until backward. Recompute them instead.
        implementation._calculate_logprobs = checkpointed_logprobs
        if self.persist_optimizer and not self._optimizer_restored:
            from art.local.checkpoints import get_last_checkpoint_dir
            from .optimizer_state import restore_optimizer_state
            latest = Path(get_last_checkpoint_dir(self.output_dir))
            saved = latest / 'retail_optimizer.pt'
            if saved.exists():
                self._last_training_mode = restore_optimizer_state(
                    saved, self._state.trainer.optimizer, expected_step=int(latest.name))
                print(json.dumps({'event': 'optimizer_restored', 'step': int(latest.name)}), flush=True)
            elif int(latest.name) > 1:
                raise RuntimeError('Missing optimizer state for resumed RL checkpoint')
            self._optimizer_restored = True
        async for metrics in super()._train_shared(disk_packed_tensors, config, _config, verbose=verbose):
            yield metrics
        if self.persist_optimizer:
            from art.local.checkpoints import get_last_checkpoint_dir
            from .optimizer_state import save_optimizer_state
            latest = Path(get_last_checkpoint_dir(self.output_dir))
            save_optimizer_state(latest / 'retail_optimizer.pt', self._state.trainer.optimizer,
                                 step=int(latest.name), mode='rl')
            print(json.dumps({'event': 'optimizer_saved', 'step': int(latest.name)}), flush=True)

    async def train_sft(self, batches, verbose=False):
        # Unsloth's GRPOTrainer.__init__ ends with for_inference(). ART's
        # standalone SFT loop calls only train(), which leaves checkpointing off.
        model = self._state.peft_model
        model.for_training(use_gradient_checkpointing=True)
        model.config.use_cache = False
        layers = [m for m in model.modules() if hasattr(m, "gradient_checkpointing")]
        active = sum(bool(m.gradient_checkpointing) for m in layers)
        diagnostic = {"event": "sft_training_mode", "checkpointing_modules": len(layers),
                      "active_checkpointing_modules": active, "training": model.training}
        print(json.dumps(diagnostic), flush=True)
        if not layers or active != len(layers) or not model.training:
            raise RuntimeError("SFT gradient checkpointing did not activate")
        async for metrics in super().train_sft(batches, verbose=verbose):
            yield metrics


class RetailLocalBackend(LocalBackend):
    def __init__(self, *args, persist_optimizer=False, **kwargs):
        super().__init__(*args, **kwargs)
        self.persist_optimizer = persist_optimizer

    async def _get_service(self, model):
        # Keep subprocess ownership local; upstream's global pkill can affect
        # another ART experiment running under the same account.
        from art.dev.get_model_config import get_model_config
        from art.dev.validate import is_dedicated_mode
        from art.utils.output_dirs import get_model_dir
        from mp_actors import move_to_child_process

        if model.name not in self._services:
            output_dir = get_model_dir(model=model, art_path=self._path)
            config = get_model_config(base_model=model.base_model, output_dir=output_dir,
                                      config=model._internal_config)
            if is_dedicated_mode(config) or config.get("tinker_args") is not None:
                raise ValueError("RetailLocalBackend supports the single-GPU Unsloth runtime only")
            os.environ["IMPORT_UNSLOTH"] = "1"
            service = RetailUnslothService(model_name=model.name, base_model=model.base_model,
                                           config=config, output_dir=output_dir,
                                           persist_optimizer=self.persist_optimizer)
            if not self._in_process:
                service = move_to_child_process(service, process_name="retail-model-service")
            self._services[model.name] = service
        return self._services[model.name]
