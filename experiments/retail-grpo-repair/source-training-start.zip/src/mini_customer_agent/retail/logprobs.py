"""Memory-bounded vocabulary projection with unchanged logprob/entropy math."""


def checkpointed_logprobs(lm_head_t, hidden_states, next_input_ids, chunk_size):
    import torch
    import torch.utils.checkpoint as checkpoint_module
    # Unsloth 2025.12's wrapper omits PyTorch 2.9's new `early_stop`
    # positional argument in the non-reentrant implementation. Its saved
    # original retains the correct signature; model-layer checkpointing stays
    # under Unsloth's control.
    checkpoint = getattr(checkpoint_module, "_old_checkpoint", checkpoint_module.checkpoint)

    lm_head_t = lm_head_t.to(hidden_states.dtype)

    def project(states, head, targets):
        logits = torch.matmul(states, head)
        selected = torch.gather(logits, dim=-1, index=targets.unsqueeze(-1)).squeeze(-1)
        normalizer = torch.logsumexp(logits, dim=-1)
        full_logprobs = logits - normalizer.unsqueeze(-1)
        entropy = (-torch.exp(full_logprobs) * full_logprobs).sum(dim=-1)
        return selected - normalizer, entropy

    logprobs, entropies = [], []
    for start in range(0, hidden_states.shape[1], chunk_size):
        states = hidden_states[:, start:start + chunk_size, :]
        targets = next_input_ids[:, start:start + chunk_size]
        if torch.is_grad_enabled() and (states.requires_grad or lm_head_t.requires_grad):
            values = checkpoint(project, states, lm_head_t, targets,
                                use_reentrant=False, preserve_rng_state=False)
        else:
            values = project(states, lm_head_t, targets)
        logprobs.append(values[0])
        entropies.append(values[1])
    return torch.cat(logprobs, dim=1), torch.cat(entropies, dim=1)
